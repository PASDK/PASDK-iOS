//
//  PlainAD.h
//  PASDK
//
//  Created by Mirinda on 16/7/27.
//  Copyright © 2016年 Mirinda. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <PASDK/PlainAD.h>
#import <PASDK/ALSADExternalDelegate.h>
#import <PASDK/ALSElementModel.h>
#import <PASDK/ALSNativeAd.h>
#import <PASDK/ALSNativeModelDelegate.h>
#import <PASDK/ALSRewardVideoDelegate.h>
#import <PASDK/ALSNativeVideoModel.h>
#import <PASDK/ALSNativeVideoDelegate.h>
#import <PASDK/ALSVideoViewController.h>
#import <PASDK/ALSMediaView.h>
#import <PASDK/ALSADMRAIDVIew.h>
#import <PASDK/ALSSplashAdDelegate.h>

//! Project version number for PASDK.
FOUNDATION_EXPORT double PASDK_VERSIONNumber;
//! Project version string for PASDK.
FOUNDATION_EXPORT const unsigned char PASDK_VERSIONString[];

// In this header, you should import all the public headers of your framework using statements like #import <PASDK/PublicHeader.h>
