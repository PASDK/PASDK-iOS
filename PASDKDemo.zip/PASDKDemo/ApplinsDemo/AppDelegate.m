
//  Created by on 2018/12/26.
//  Copyright © 2018. All rights reserved.
//
#define ALS_SCREEN_WIDTH ([[UIScreen mainScreen] bounds].size.width)
#define ALS_SCREEN_HEIGHT ([[UIScreen mainScreen] bounds].size.height)
#import "AppDelegate.h"
@import PASDK;
@interface AppDelegate ()<ALSSplashAdDelegate>
@property(nonatomic, strong) UIView *v;
@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    [[PlainAD shareSDK] initSDK:@"81427091"];//   57141680
    [[UIApplication sharedApplication] setStatusBarHidden:NO withAnimation:NO];
    
    UIView * ad = [[UIView alloc]initWithFrame:CGRectMake(0, 3*ALS_SCREEN_HEIGHT/4, ALS_SCREEN_WIDTH, ALS_SCREEN_HEIGHT/4)];
    ad.backgroundColor = [UIColor colorWithRed:130/255.0 green:130/255.0 blue:130/255.0 alpha:0.6];
    
    UIStoryboard *s = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    UIViewController *vc = [s instantiateInitialViewController];
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.window.rootViewController = vc;
    [self.window makeKeyAndVisible];
    UIImage *splashImage = [UIImage imageNamed:@"splashImage"];
    splashImage = [AppDelegate  imageResize:splashImage andResizeTo:[UIScreen mainScreen].bounds.size];
    [[PlainAD shareSDK] preloadaAndShowSplashAd:@"81427091" delegate:self window:self.window launchImage:splashImage customAdView:ad waitAdTime:10.0 isTest:NO];
    // Override point for customization after application launch.
    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
//    if (!self.v) {
//        UIImage *splashImage = [UIImage imageNamed:@"splashImage"];
//        self.v = [[UIView alloc]initWithFrame:[UIScreen mainScreen].bounds];
//        self.v.backgroundColor = [UIColor colorWithPatternImage:splashImage];
//    }
//    [self.window addSubview:self.v];
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
//    UIView * ad = [[UIView alloc]initWithFrame:CGRectMake(0, 3*ALS_SCREEN_HEIGHT/4, ALS_SCREEN_WIDTH, ALS_SCREEN_HEIGHT/4)];
//    ad.backgroundColor = [UIColor colorWithRed:130/255.0 green:130/255.0 blue:130/255.0 alpha:0.6];
//    UIImage *splashImage = [UIImage imageNamed:@"splashImage"];
//    //    UIView *v = [[UIView alloc]initWithFrame:[UIScreen mainScreen].bounds];
//    splashImage = [AppDelegate  imageResize:splashImage andResizeTo:[UIScreen mainScreen].bounds.size];
//    //    v.backgroundColor = [UIColor colorWithPatternImage:splashImage];
//    //    [self.window addSubview:v];
//    [[PlainAD shareSDK] preloadaAndShowSplashAd:@"81427091" delegate:self window:self.window launchImage:splashImage customAdView:ad waitAdTime:3.0 isTest:NO];
//    [self.v removeFromSuperview];
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

+ (UIImage *)imageResize:(UIImage*)img andResizeTo:(CGSize)newSize
{
    CGFloat scale = [[UIScreen mainScreen] scale];
    UIGraphicsBeginImageContextWithOptions(newSize, NO, scale);
    [img drawInRect:CGRectMake(0,0,newSize.width,newSize.height)];
    UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
}


//ALSSplashAdDelegate
- (void)ALSSplashAdFailed:(NSError*)error {
    NSLog(@"ALSSplashAdFailed");
}
- (void)ALSSplashAdClicked {
    NSLog(@"ALSSplashAdClicked");
}
- (void)ALSSplashAdJumpedFailed {
    NSLog(@"ALSSplashAdJumpedFailed");
}

- (void)ALSSplashAdIsShow {
    NSLog(@"ALSSplashAdIsShow");
}
@end
